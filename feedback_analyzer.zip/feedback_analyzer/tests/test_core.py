import json, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from core import storage, analytics as A, export, validation as V
from core.models import Feedback

D = Path(__file__).resolve().parent.parent / "data"
GOOD = dict(course="cs101", rating="4", category="content", comment="Very helpful lectures", date="2026-01-05", student="")


class T(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp()); self.p = self.tmp / "f.json"

    def test_validation_rejects(self):
        for bad in ({"rating": "9"}, {"rating": "abc"}, {"rating": ""}, {"rating": "3.5"}, {"comment": "  "},
                    {"comment": "x" * 501}, {"course": "??"}, {"category": "Snacks"}, {"date": "2099-01-01"}, {"date": "bad"}):
            with self.assertRaises(V.ValidationError, msg=bad):
                V.validate_record({**GOOD, **bad})

    def test_validation_cleans(self):
        r = V.validate_record(GOOD)
        self.assertEqual((r["course"], r["rating"], r["category"], r["student"]), ("CS101", 4, "Content", "Anonymous"))

    def test_missing_and_corrupt_file(self):
        self.assertEqual(storage.load(self.p), [])
        self.assertTrue(self.p.exists())
        self.p.write_text("{not json")
        self.assertEqual(storage.load(self.p), [])
        self.assertTrue(self.p.with_suffix(".corrupt").exists())

    def test_persistence_roundtrip(self):
        storage.add(GOOD, self.p)
        again = storage.load(self.p)
        self.assertEqual(len(again), 1); self.assertEqual(again[0].course, "CS101")

    def test_sample_data(self):
        recs = storage.load(D / "sample_feedback.json")
        self.assertTrue(30 <= len(recs) <= 50)
        s = A.summary(recs)
        self.assertEqual(sum(s["distribution"].values()), len(recs))
        self.assertTrue(1 <= s["avg"] <= 5)
        self.assertTrue(any("reads negative" in w["msg"] for w in A.warnings(recs)))
        self.assertTrue(any("reads positive" in w["msg"] for w in A.warnings(recs)))

    def test_import_error_log(self):
        res = storage.import_csv(D / "legacy_with_errors.csv", self.p)
        self.assertEqual(res["imported"], 2)
        self.assertEqual([r for r, _ in res["errors"]], [3, 4, 5, 6, 7, 8])
        res2 = storage.import_csv(D / "legacy_with_errors.csv", self.p)  # duplicates skipped
        self.assertEqual(res2["imported"], 0)

    def test_search(self):
        recs = storage.load(D / "sample_feedback.json")
        self.assertTrue(all(r.category == "Teaching" for r in A.search(recs, category="Teaching")))
        self.assertTrue(all("helpful" in r.comment.lower() for r in A.search(recs, "helpful")))

    def test_status_and_sentiment(self):
        self.assertEqual([A.status_for(x) for x in (4.6, 4, 3.2, 2.9)], ["Excellent", "Good", "Watch", "Critical"])
        self.assertGreater(A.sentiment("great and helpful"), 0); self.assertLess(A.sentiment("boring and confusing"), 0)

    def test_empty_summary(self):
        self.assertEqual(A.summary([]), {"total": 0})
        self.assertIn("No data", export.to_markdown([]))

    def test_export(self):
        recs = storage.load(D / "sample_feedback.json")
        paths = export.export_all(recs, self.tmp / "out")
        self.assertEqual({p.name for p in paths}, {"report.md", "audit_log.txt", "report.csv", "distribution.png", "by_course.png", "trend.png"})
        self.assertTrue(all(p.stat().st_size > 0 for p in paths))


if __name__ == "__main__":
    unittest.main()
