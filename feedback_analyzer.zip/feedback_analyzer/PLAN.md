# Course Feedback Analyzer — Implementation Plan

Project #7 (Everyday Innovators). Collect student feedback; summarize ratings and common comments.

## Architecture
One UI-independent core, two front ends (so the brief's terminal requirement and a modern GUI both work).

    core/models.py      Feedback dataclass, constants (courses, categories)
    core/validation.py  Defensive validators + centralized form validation
    core/storage.py     JSON persistence, corrupt-file recovery, CSV bulk import w/ row error log
    core/analytics.py   Averages, distributions, trends, sentiment, common keywords, warnings, search
    core/export.py      Markdown / TXT audit log / CSV reports
    core/charts.py      Matplotlib figures (distribution, per-course, trend)
    cli.py              Menu-driven terminal app (must-have)
    app.py              Streamlit GUI (stretch: GUI)
    seed.py             Generates data/sample_feedback.{csv,json} (40 varied rows incl. edge cases)
    tests/              pytest/unittest suite

## Phases
1. Scaffold + data model (dataclass, constants)
2. Validation: rating 1-5, course code regex, date not in future, comment 5-500 chars, no blank
3. Persistence: atomic JSON writes; FileNotFound / JSONDecodeError -> clean template + .corrupt backup
4. Analytics: mean/median, rating distribution, per-course & per-category stats, monthly trend,
   lexicon sentiment, top keywords/bigrams (stopword filtered), status indicators (Excellent/Good/Watch/Critical)
5. Search: keyword + category + course + rating-range filters
6. Warnings: critical avg (<3.0), anomalous (high rating + negative text and vice versa),
   duplicates, very short comments, low-sample courses
7. Export + charts
8. Bulk CSV import with row-by-row error log
9. CLI dispatch loop; Streamlit pages: Dashboard, Submit, Browse/Search, Import, Export
10. Seed data + end-to-end tests; demo script (add invalid -> corrected, analytics, restart persistence, export)

## Demo flow
Launch -> branded welcome -> submit bad input (rating 9, blank comment) rejected with message
-> submit valid -> dashboard -> restart app, data persists -> export report + chart.

## Run
    pip install streamlit matplotlib pandas
    python seed.py
    streamlit run app.py      # GUI
    python cli.py             # terminal
    python -m unittest discover tests
