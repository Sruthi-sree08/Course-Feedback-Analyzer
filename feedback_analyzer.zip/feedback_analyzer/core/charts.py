from __future__ import annotations
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
from . import analytics as A

PALETTE = {"main": "#6C5CE7", "good": "#00B894", "warn": "#FDCB6E", "bad": "#D63031", "grid": "#E5E7EB"}
STAR_COLORS = ["#D63031", "#E17055", "#FDCB6E", "#55EFC4", "#00B894"]


def _style(ax, title):
    ax.set_title(title, fontsize=13, fontweight="bold", loc="left")
    ax.grid(axis="y", color=PALETTE["grid"]); ax.set_axisbelow(True)
    for s in ("top", "right"): ax.spines[s].set_visible(False)


def distribution_fig(records):
    d = A.distribution(records)
    fig, ax = plt.subplots(figsize=(6, 3.6))
    bars = ax.bar([str(k) for k in d], list(d.values()), color=STAR_COLORS)
    ax.bar_label(bars); ax.set_xlabel("Stars"); ax.set_ylabel("Responses")
    _style(ax, "Rating distribution"); fig.tight_layout(); return fig


def course_fig(records):
    rows = A.group_stats(records, "course")[::-1]
    fig, ax = plt.subplots(figsize=(6, max(3, 0.4 * len(rows) + 1)))
    colors = [PALETTE["bad"] if r["avg"] < 3 else PALETTE["warn"] if r["avg"] < 3.5 else PALETTE["good"] for r in rows]
    bars = ax.barh([r["course"] for r in rows], [r["avg"] for r in rows], color=colors)
    ax.bar_label(bars, fmt="%.2f", padding=3); ax.set_xlim(0, 5.4); ax.axvline(3, ls="--", c="#999", lw=1)
    ax.grid(axis="x", color=PALETTE["grid"]); ax.set_axisbelow(True); ax.set_title("Average rating by course", fontsize=13, fontweight="bold", loc="left")
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    fig.tight_layout(); return fig


def trend_fig(records):
    t = A.monthly_trend(records)
    fig, ax = plt.subplots(figsize=(6, 3.6))
    ax.plot([m for m, _, _ in t], [a for _, a, _ in t], marker="o", color=PALETTE["main"], lw=2.5)
    ax.set_ylim(1, 5); ax.set_ylabel("Avg rating"); plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _style(ax, "Monthly rating trend"); fig.tight_layout(); return fig


def save_all(records, out_dir) -> list[Path]:
    out = []
    for name, fn in (("distribution.png", distribution_fig), ("by_course.png", course_fig), ("trend.png", trend_fig)):
        p = Path(out_dir) / name
        fig = fn(records); fig.savefig(p, dpi=150); plt.close(fig); out.append(p)
    return out
