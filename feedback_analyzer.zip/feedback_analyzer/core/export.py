from __future__ import annotations
import csv, io
from datetime import datetime
from pathlib import Path
from . import analytics as A
from .models import Feedback
from .storage import CSV_FIELDS


def to_markdown(records: list[Feedback]) -> str:
    s = A.summary(records)
    if not s["total"]:
        return "# Course Feedback Report\n\n_No data._\n"
    L = [f"# Course Feedback Report", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", "",
         "## Executive Summary",
         f"- **Total responses:** {s['total']}",
         f"- **Average rating:** {s['avg']} / 5 ({s['status']})",
         f"- **Median:** {s['median']}",
         f"- **Satisfied (4-5):** {s['pct_positive']}%",
         f"- **Trend:** {s['trend_direction']}",
         f"- **Sentiment:** " + ", ".join(f"{k} {v}" for k, v in s["sentiment"].items()), "",
         "## Rating Distribution", "| Stars | Count |", "|---|---|"]
    L += [f"| {k} | {v} |" for k, v in s["distribution"].items()]
    L += ["", "## By Course", "| Course | Reviews | Avg | Status |", "|---|---|---|---|"]
    L += [f"| {r['course']} | {r['count']} | {r['avg']} | {r['status']} |" for r in s["courses"]]
    L += ["", "## By Category", "| Category | Reviews | Avg |", "|---|---|---|"]
    L += [f"| {r['category']} | {r['count']} | {r['avg']} |" for r in s["categories"]]
    L += ["", "## Common Themes", ", ".join(f"{w} ({c})" for w, c in s["keywords"]) or "_none_"]
    w = A.warnings(records)
    if w:
        L += ["", "## Warnings"] + [f"- **{x['level'].upper()}**: {x['msg']}" for x in w]
    return "\n".join(L) + "\n"


def to_audit_log(records: list[Feedback]) -> str:
    lines = [f"AUDIT LOG {datetime.now():%Y-%m-%d %H:%M:%S} | {len(records)} records", "-" * 70]
    for r in sorted(records, key=lambda r: r.date):
        lines.append(f"{r.date} | {r.id} | {r.course:<8} | {r.rating}/5 | {r.category:<10} | {r.student} | {r.comment}")
    lines += ["-" * 70, "WARNINGS:"] + [f"  [{w['level']}] {w['msg']}" for w in A.warnings(records)]
    return "\n".join(lines) + "\n"


def to_csv(records: list[Feedback]) -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=CSV_FIELDS)
    w.writeheader()
    for r in records:
        w.writerow(r.to_dict())
    return buf.getvalue()


def export_all(records: list[Feedback], out_dir: Path | str, with_charts: bool = True) -> list[Path]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    files = {"report.md": to_markdown(records), "audit_log.txt": to_audit_log(records), "report.csv": to_csv(records)}
    paths = []
    for name, content in files.items():
        p = out / name
        p.write_text(content, encoding="utf-8")
        paths.append(p)
    if with_charts and records:
        from . import charts
        paths += charts.save_all(records, out)
    return paths
