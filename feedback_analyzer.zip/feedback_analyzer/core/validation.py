from __future__ import annotations
import re
from datetime import date, datetime
from .models import CATEGORIES, RATING_MIN, RATING_MAX, COMMENT_MIN, COMMENT_MAX

COURSE_RE = re.compile(r"^[A-Z]{2,4}[- ]?\d{3}$")


class ValidationError(ValueError):
    pass


def clean_text(s) -> str:
    """Collapse whitespace, strip control chars."""
    s = "" if s is None else str(s)
    s = re.sub(r"[\x00-\x1f\x7f]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def validate_course(v) -> str:
    v = clean_text(v).upper()
    if not COURSE_RE.match(v):
        raise ValidationError("Course code must look like CS101 or MATH-204 (2-4 letters + 3 digits).")
    return v.replace(" ", "-")


def validate_rating(v) -> int:
    if isinstance(v, bool):
        raise ValidationError("Rating must be a whole number.")
    try:
        f = float(str(v).strip())
    except (TypeError, ValueError):
        raise ValidationError("Rating must be a number between 1 and 5.")
    if f != int(f):
        raise ValidationError("Rating must be a whole number (1-5).")
    r = int(f)
    if not RATING_MIN <= r <= RATING_MAX:
        raise ValidationError(f"Rating must be between {RATING_MIN} and {RATING_MAX}.")
    return r


def validate_category(v) -> str:
    v = clean_text(v).title()
    if v not in CATEGORIES:
        raise ValidationError(f"Category must be one of: {', '.join(CATEGORIES)}.")
    return v


def validate_comment(v) -> str:
    v = clean_text(v)
    if not v:
        raise ValidationError("Comment cannot be blank.")
    if len(v) < COMMENT_MIN:
        raise ValidationError(f"Comment too short (min {COMMENT_MIN} characters).")
    if len(v) > COMMENT_MAX:
        raise ValidationError(f"Comment too long (max {COMMENT_MAX} characters).")
    return v


def validate_date(v) -> str:
    if isinstance(v, (date, datetime)):
        d = v.date() if isinstance(v, datetime) else v
    else:
        try:
            d = datetime.strptime(clean_text(v), "%Y-%m-%d").date()
        except ValueError:
            raise ValidationError("Date must be in YYYY-MM-DD format.")
    if d > date.today():
        raise ValidationError("Date cannot be in the future.")
    if d.year < 2000:
        raise ValidationError("Date is implausibly old (before 2000).")
    return d.isoformat()


def validate_student(v) -> str:
    v = clean_text(v)
    if not v:
        return "Anonymous"
    if len(v) > 60:
        raise ValidationError("Student name too long (max 60).")
    return v


def validate_record(raw: dict) -> dict:
    """Validate a whole form/row. Returns cleaned dict or raises ValidationError
    listing ALL problems at once."""
    errors, out = [], {}
    checks = [("course", validate_course), ("rating", validate_rating), ("category", validate_category),
              ("comment", validate_comment), ("date", validate_date), ("student", validate_student)]
    for key, fn in checks:
        try:
            out[key] = fn(raw.get(key, ""))
        except ValidationError as e:
            errors.append(f"{key}: {e}")
    if errors:
        raise ValidationError("; ".join(errors))
    return out
