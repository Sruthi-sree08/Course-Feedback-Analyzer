from __future__ import annotations
import csv, json, os, shutil, tempfile
from pathlib import Path
from .models import Feedback
from .validation import validate_record, ValidationError

DEFAULT_PATH = Path(__file__).resolve().parent.parent / "data" / "feedback.json"
CSV_FIELDS = ["id", "date", "course", "student", "rating", "category", "comment"]


def load(path: Path | str = DEFAULT_PATH) -> list[Feedback]:
    """Load records. Missing/corrupt file -> clean template (corrupt file backed up)."""
    path = Path(path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("records"), list):
            raise json.JSONDecodeError("bad schema", "", 0)
    except FileNotFoundError:
        save([], path)
        return []
    except (json.JSONDecodeError, UnicodeDecodeError):
        shutil.copy(path, path.with_suffix(".corrupt"))
        save([], path)
        return []
    records = []
    for row in data["records"]:
        try:
            records.append(Feedback.from_dict(row))
        except (KeyError, ValueError, TypeError):
            continue  # skip malformed record, keep the rest
    return records


def save(records: list[Feedback], path: Path | str = DEFAULT_PATH) -> None:
    """Atomic write so a crash can't leave a half-written file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"version": 1, "records": [r.to_dict() for r in records]}
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def add(raw: dict, path: Path | str = DEFAULT_PATH) -> Feedback:
    rec = Feedback.from_dict(validate_record(raw))
    records = load(path)
    records.append(rec)
    save(records, path)
    return rec


def delete(rec_id: str, path: Path | str = DEFAULT_PATH) -> bool:
    records = load(path)
    kept = [r for r in records if r.id != rec_id]
    save(kept, path)
    return len(kept) != len(records)


def import_csv(csv_path: Path | str, path: Path | str = DEFAULT_PATH) -> dict:
    """Bulk import. Returns {'imported': n, 'skipped': n, 'errors': [(row_no, msg)]}."""
    errors, good = [], []
    try:
        text = Path(csv_path).read_text(encoding="utf-8-sig")
    except (FileNotFoundError, UnicodeDecodeError) as e:
        return {"imported": 0, "skipped": 0, "errors": [(0, f"Cannot read file: {e}")]}
    return import_csv_text(text, path)


def import_csv_text(text: str, path: Path | str = DEFAULT_PATH) -> dict:
    errors, good = [], []
    reader = csv.DictReader(text.splitlines())
    required = {"course", "rating", "category", "comment", "date"}
    if not reader.fieldnames or not required <= {h.strip().lower() for h in reader.fieldnames}:
        return {"imported": 0, "skipped": 0,
                "errors": [(0, f"Missing required columns: {sorted(required)}")]}
    existing = load(path)
    seen = {(r.course, r.date, r.comment) for r in existing}
    for i, row in enumerate(reader, start=2):  # row 1 is the header
        row = {(k or "").strip().lower(): v for k, v in row.items()}
        try:
            clean = validate_record(row)
        except ValidationError as e:
            errors.append((i, str(e)))
            continue
        key = (clean["course"], clean["date"], clean["comment"])
        if key in seen:
            errors.append((i, "duplicate of an existing record"))
            continue
        seen.add(key)
        good.append(Feedback.from_dict(clean))
    if good:
        save(existing + good, path)
    return {"imported": len(good), "skipped": len(errors), "errors": errors}
