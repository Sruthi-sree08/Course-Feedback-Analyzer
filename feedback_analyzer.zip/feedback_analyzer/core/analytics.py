from __future__ import annotations
import re, statistics
from collections import Counter, defaultdict
from .models import Feedback

STOP = set("""a an the and or but if so to of in on at for with from by is are was were be been being it its this
that these those i me my we our you your they them their he she his her as not no do does did have has had
very really just also too can could would should will than then there here what when which who how about
into out up down over again more most some any all one get got much many lot lots bit""".split())
POS = set("""great good excellent amazing helpful clear engaging interesting enjoyed love loved useful fantastic
well organized inspiring supportive best awesome fun easy fair valuable thorough responsive brilliant
informative practical""".split())
NEG = set("""bad poor boring confusing unclear difficult hard terrible worst slow disorganized unfair rushed
overloaded heavy lacking useless outdated stressful waste frustrating confused late missing broken
crowded noisy boring""".split())


def tokens(text: str) -> list[str]:
    return re.findall(r"[a-z']{2,}", text.lower())


def sentiment(text: str) -> float:
    """-1..1 lexicon score."""
    t = tokens(text)
    p, n = sum(w in POS for w in t), sum(w in NEG for w in t)
    return 0.0 if p + n == 0 else (p - n) / (p + n)


def sentiment_label(score: float) -> str:
    return "Positive" if score > 0.2 else "Negative" if score < -0.2 else "Neutral"


def status_for(avg: float) -> str:
    if avg >= 4.5: return "Excellent"
    if avg >= 3.5: return "Good"
    if avg >= 3.0: return "Watch"
    return "Critical"


def top_keywords(records: list[Feedback], n: int = 10) -> list[tuple[str, int]]:
    c = Counter(w for r in records for w in set(tokens(r.comment)) if w not in STOP and len(w) > 2)
    return c.most_common(n)


def top_phrases(records: list[Feedback], n: int = 8) -> list[tuple[str, int]]:
    c = Counter()
    for r in records:
        t = [w for w in tokens(r.comment)]
        for a, b in zip(t, t[1:]):
            if a not in STOP and b not in STOP:
                c[f"{a} {b}"] += 1
    return [(p, k) for p, k in c.most_common(n) if k > 1]


def distribution(records: list[Feedback]) -> dict[int, int]:
    c = Counter(r.rating for r in records)
    return {i: c.get(i, 0) for i in range(1, 6)}


def group_stats(records: list[Feedback], key: str) -> list[dict]:
    g = defaultdict(list)
    for r in records:
        g[getattr(r, key)].append(r.rating)
    rows = [{key: k, "count": len(v), "avg": round(statistics.mean(v), 2), "status": status_for(statistics.mean(v))}
            for k, v in g.items()]
    return sorted(rows, key=lambda x: x["avg"], reverse=True)


def monthly_trend(records: list[Feedback]) -> list[tuple[str, float, int]]:
    g = defaultdict(list)
    for r in records:
        g[r.date[:7]].append(r.rating)
    return [(m, round(statistics.mean(v), 2), len(v)) for m, v in sorted(g.items())]


def trend_direction(records: list[Feedback]) -> str:
    t = monthly_trend(records)
    if len(t) < 2:
        return "Not enough data"
    d = t[-1][1] - t[0][1]
    return "Improving" if d > 0.2 else "Declining" if d < -0.2 else "Stable"


def summary(records: list[Feedback]) -> dict:
    if not records:
        return {"total": 0}
    ratings = [r.rating for r in records]
    avg = statistics.mean(ratings)
    sents = [sentiment(r.comment) for r in records]
    labels = Counter(sentiment_label(s) for s in sents)
    return {
        "total": len(records),
        "avg": round(avg, 2),
        "median": statistics.median(ratings),
        "status": status_for(avg),
        "distribution": distribution(records),
        "pct_positive": round(100 * sum(r >= 4 for r in ratings) / len(ratings), 1),
        "courses": group_stats(records, "course"),
        "categories": group_stats(records, "category"),
        "trend": monthly_trend(records),
        "trend_direction": trend_direction(records),
        "keywords": top_keywords(records),
        "phrases": top_phrases(records),
        "sentiment": {k: labels.get(k, 0) for k in ("Positive", "Neutral", "Negative")},
    }


def warnings(records: list[Feedback]) -> list[dict]:
    """Threshold indicators. level: critical | warning | info."""
    out = []
    for row in group_stats(records, "course"):
        if row["count"] >= 3 and row["avg"] < 3.0:
            out.append({"level": "critical", "msg": f"{row['course']} average {row['avg']} is below 3.0 ({row['count']} reviews)"})
        elif row["count"] < 3:
            out.append({"level": "info", "msg": f"{row['course']} has only {row['count']} review(s) - low sample"})
    seen = Counter((r.course, r.comment.lower()) for r in records)
    for r in records:
        s = sentiment(r.comment)
        if r.rating >= 4 and s <= -0.5:
            out.append({"level": "warning", "msg": f"[{r.id}] {r.course}: rating {r.rating} but comment reads negative"})
        elif r.rating <= 2 and s >= 0.5:
            out.append({"level": "warning", "msg": f"[{r.id}] {r.course}: rating {r.rating} but comment reads positive"})
        if seen[(r.course, r.comment.lower())] > 1:
            out.append({"level": "warning", "msg": f"[{r.id}] {r.course}: duplicate comment"})
        if len(r.comment) < 10:
            out.append({"level": "info", "msg": f"[{r.id}] {r.course}: very short comment"})
    t = monthly_trend(records)
    if len(t) >= 2 and t[-1][1] - t[-2][1] <= -0.5:
        out.append({"level": "warning", "msg": f"Average dropped {t[-2][1]} -> {t[-1][1]} month over month"})
    order = {"critical": 0, "warning": 1, "info": 2}
    return sorted(out, key=lambda w: order[w["level"]])


def search(records: list[Feedback], keyword: str = "", category: str = "", course: str = "",
           min_rating: int = 1, max_rating: int = 5) -> list[Feedback]:
    kw = keyword.lower().strip()
    res = []
    for r in records:
        if category and r.category != category: continue
        if course and r.course != course.upper(): continue
        if not (min_rating <= r.rating <= max_rating): continue
        if kw and kw not in r.comment.lower() and kw not in r.course.lower() and kw not in r.student.lower(): continue
        res.append(r)
    return res
