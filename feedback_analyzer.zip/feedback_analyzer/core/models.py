from __future__ import annotations
from dataclasses import dataclass, asdict, field
import uuid

CATEGORIES = ["Content", "Teaching", "Workload", "Assessment", "Facilities", "Other"]
RATING_MIN, RATING_MAX = 1, 5
COMMENT_MIN, COMMENT_MAX = 5, 500


@dataclass
class Feedback:
    course: str
    rating: int
    category: str
    comment: str
    date: str                      # ISO YYYY-MM-DD
    student: str = "Anonymous"
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Feedback":
        return cls(
            course=str(d["course"]), rating=int(d["rating"]), category=str(d["category"]),
            comment=str(d["comment"]), date=str(d["date"]),
            student=str(d.get("student") or "Anonymous"),
            id=str(d.get("id") or uuid.uuid4().hex[:8]),
        )
