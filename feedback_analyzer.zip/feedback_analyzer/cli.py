"""Menu-driven terminal interface."""
from pathlib import Path
from datetime import date
from core import storage, analytics as A, export, validation as V
from core.models import CATEGORIES

B, G, Y, R, C, X = "\033[1m", "\033[92m", "\033[93m", "\033[91m", "\033[96m", "\033[0m"
BANNER = f"""{C}{B}
 ╔══════════════════════════════════════════╗
 ║     COURSE FEEDBACK ANALYZER  v1.0       ║
 ║     Collect · Validate · Summarize       ║
 ╚══════════════════════════════════════════╝{X}"""


def ask(prompt, validator, default=None):
    """Centralized input wrapper: loops until valid."""
    while True:
        try:
            raw = input(f"{prompt}{f' [{default}]' if default else ''}: ").strip()
        except EOFError:
            raise SystemExit
        if not raw and default is not None:
            raw = default
        try:
            return validator(raw)
        except V.ValidationError as e:
            print(f"{R}  ✗ {e}{X}")


def table(rows, headers, widths):
    fmt = " | ".join(f"{{:<{w}}}" for w in widths)
    print(B + fmt.format(*headers) + X); print("-+-".join("-" * w for w in widths))
    for r in rows:
        print(fmt.format(*[str(c)[:w] for c, w in zip(r, widths)]))


def paged(rows, headers, widths, size=15):
    for i in range(0, len(rows), size):
        table(rows[i:i + size], headers, widths)
        if i + size < len(rows) and input(f"-- {i + size}/{len(rows)} -- Enter for more, q to stop: ").lower() == "q":
            break


def add_entry():
    raw = {"course": ask("Course code (e.g. CS101)", V.validate_course),
           "rating": ask("Rating 1-5", V.validate_rating),
           "category": ask(f"Category ({'/'.join(CATEGORIES)})", V.validate_category),
           "comment": ask("Comment", V.validate_comment),
           "date": ask("Date YYYY-MM-DD", V.validate_date, date.today().isoformat()),
           "student": ask("Student name (blank = Anonymous)", V.validate_student)}
    rec = storage.add(raw)
    print(f"{G}✓ Saved {rec.id}{X}")


def view_all():
    recs = storage.load()
    paged([(r.id, r.date, r.course, r.rating, r.category, r.comment) for r in recs],
          ["ID", "Date", "Course", "★", "Category", "Comment"], [8, 10, 8, 2, 10, 45])


def do_search():
    recs = storage.load()
    kw = input("Keyword (blank=any): ")
    cat = input(f"Category ({'/'.join(CATEGORIES)}, blank=any): ").strip().title()
    res = A.search(recs, kw, cat if cat in CATEGORIES else "")
    print(f"{len(res)} match(es)")
    paged([(r.id, r.date, r.course, r.rating, r.category, r.comment) for r in res],
          ["ID", "Date", "Course", "★", "Category", "Comment"], [8, 10, 8, 2, 10, 45])


def show_summary():
    recs = storage.load(); s = A.summary(recs)
    if not s["total"]:
        print(f"{Y}No data yet.{X}"); return
    col = {"Excellent": G, "Good": G, "Watch": Y, "Critical": R}[s["status"]]
    print(f"\n{B}EXECUTIVE SUMMARY{X}\n Responses: {s['total']}  Avg: {s['avg']}  Median: {s['median']}  "
          f"Status: {col}{s['status']}{X}  Satisfied: {s['pct_positive']}%  Trend: {s['trend_direction']}")
    for k, v in s["distribution"].items():
        print(f" {k}★ {'█' * v} {v}")
    table([(r["course"], r["count"], r["avg"], r["status"]) for r in s["courses"]], ["Course", "N", "Avg", "Status"], [10, 5, 6, 10])
    print("Top themes:", ", ".join(f"{w}({c})" for w, c in s["keywords"]))
    for w in A.warnings(recs)[:8]:
        c = R if w["level"] == "critical" else Y
        print(f"{c} ⚠ {w['msg']}{X}")


def do_import():
    p = input("CSV path: ").strip().strip('"')
    res = storage.import_csv(p)
    print(f"{G}Imported {res['imported']}{X}, skipped {res['skipped']}")
    for row, msg in res["errors"]:
        print(f"{R}  row {row}: {msg}{X}")


def do_export():
    paths = export.export_all(storage.load(), Path(__file__).parent / "exports")
    print(f"{G}Exported:{X}"); [print("  ", p) for p in paths]


MENU = [("Add feedback", add_entry), ("View all", view_all), ("Search", do_search),
        ("Executive summary", show_summary), ("Import CSV", do_import), ("Export reports + charts", do_export)]


def main():
    print(BANNER)
    while True:
        print(f"\n{B}MENU{X}")
        for i, (name, _) in enumerate(MENU, 1):
            print(f"  {i}. {name}")
        print("  0. Quit")
        c = input("Choose: ").strip()
        if c == "0":
            print("Bye!"); return
        if c.isdigit() and 1 <= int(c) <= len(MENU):
            try:
                MENU[int(c) - 1][1]()
            except KeyboardInterrupt:
                print("\nCancelled.")
        else:
            print(f"{R}Pick a number from the menu.{X}")


if __name__ == "__main__":
    main()
