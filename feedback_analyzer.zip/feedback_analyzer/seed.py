"""Generate realistic sample data: data/sample_feedback.csv + .json (40 rows) and a messy legacy CSV."""
import csv, json, random
from datetime import date, timedelta
from pathlib import Path
from core.models import Feedback
from core.storage import CSV_FIELDS

D = Path(__file__).parent / "data"
random.seed(7)
COMMENTS = {
 "Content": [(5, "Great course content, very engaging and well organized."), (4, "Interesting material and useful practical examples."),
             (2, "Content feels outdated and boring in places."), (3, "Some topics were clear, others confusing.")],
 "Teaching": [(5, "Professor is helpful, clear and very supportive."), (4, "Lectures are clear and engaging."),
              (1, "Teaching is poor and slides are confusing."), (2, "Lectures felt rushed and disorganized.")],
 "Workload": [(2, "Workload is heavy and stressful near deadlines."), (3, "Assignments are fair but time consuming."),
              (4, "Workload is manageable and well paced."), (1, "Overloaded with assignments, completely rushed.")],
 "Assessment": [(4, "Exams were fair and matched the lectures."), (2, "Grading was unfair and feedback came late."),
                (5, "Excellent project based assessment, very valuable."), (3, "Quizzes were okay, rubric could be clearer.")],
 "Facilities": [(2, "Classroom is crowded and noisy."), (4, "Lab equipment is good and responsive staff."),
                (3, "Wifi is slow but rooms are fine.")],
 "Other": [(5, "Loved the guest speakers, fantastic experience."), (3, "Fine overall, nothing special.")],
}
COURSES = {"CS101": 0.7, "CS205": 0.3, "MATH204": 0.0, "PHY110": -0.2, "ENG150": 0.5, "BIO120": -0.6}
students = ["Aarav", "Meera", "Rohan", "Sara", "Kabir", "Isha", "Anonymous", "Anonymous", "Dev", "Nina"]

rows, today = [], date.today()
for i in range(36):
    course = random.choice(list(COURSES))
    cat = random.choice(list(COMMENTS))
    base, text = random.choice(COMMENTS[cat])
    rating = max(1, min(5, round(base + COURSES[course] * random.uniform(0, 1.2) + random.choice([-1, 0, 0, 1]) * 0.5)))
    d = today - timedelta(days=random.randint(1, 150))
    rows.append(Feedback(course, rating, cat, text, d.isoformat(), random.choice(students), f"s{i:03d}"))
# edge / boundary cases
rows += [
  Feedback("CS101", 1, "Teaching", "Terrible.", (today - timedelta(days=3)).isoformat(), "Anonymous", "e001"),      # min rating, short comment
  Feedback("CS101", 5, "Content", "x" * 500, (today - timedelta(days=4)).isoformat(), "Anonymous", "e002"),          # max length
  Feedback("PHY110", 5, "Workload", "Awful, boring, and a complete waste of time.", today.isoformat(), "Dev", "e003"),  # anomaly: 5 + negative
  Feedback("BIO120", 1, "Teaching", "Amazing, helpful and brilliant lecturer!", today.isoformat(), "Nina", "e004"),    # anomaly: 1 + positive
]
(D).mkdir(exist_ok=True)
(D / "sample_feedback.json").write_text(json.dumps({"version": 1, "records": [r.to_dict() for r in rows]}, indent=2))
with open(D / "sample_feedback.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=CSV_FIELDS); w.writeheader(); [w.writerow(r.to_dict()) for r in rows]

# messy legacy file to demo row-by-row error log
(D / "legacy_with_errors.csv").write_text(
"""course,rating,category,comment,date,student
CS101,5,Content,Really enjoyed the labs and clear explanations,2026-10-01,Ravi
CS101,9,Teaching,Rating out of range here,2026-10-02,Ravi
cs-1,4,Content,Bad course code format here,2026-10-03,Ravi
MATH204,3,Snacks,Unknown category given,2026-10-04,Ravi
MATH204,four,Workload,Non numeric rating present,2026-10-05,Ravi
ENG150,4,Assessment,,2026-10-06,Ravi
ENG150,4,Assessment,Date is in the future for sure,2099-01-01,Ravi
BIO120,2,Facilities,Lab was crowded and equipment broken,2026-10-07,
""")
print(f"wrote {len(rows)} sample rows + legacy_with_errors.csv")
