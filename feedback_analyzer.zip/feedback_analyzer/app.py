"""Course Feedback Analyzer — Streamlit GUI.  Run: streamlit run app.py"""
from datetime import date
from pathlib import Path
import pandas as pd
import streamlit as st
from core import storage, analytics as A, export, charts, validation as V
from core.models import CATEGORIES

st.set_page_config(page_title="Course Feedback Analyzer", page_icon="🎓", layout="wide")

st.markdown("""
<style>
.hero{background:linear-gradient(120deg,#6C5CE7,#a29bfe);color:#fff;padding:22px 28px;border-radius:16px;margin-bottom:18px}
.hero h1{margin:0;font-size:1.9rem;color:#fff}.hero p{margin:4px 0 0;opacity:.9}
.card{background:#fff;border-radius:14px;padding:16px 18px;box-shadow:0 2px 10px rgba(0,0,0,.06);border-left:5px solid #6C5CE7}
.card .v{font-size:1.9rem;font-weight:700}.card .l{color:#6b7280;font-size:.85rem}
.pill{padding:2px 10px;border-radius:99px;font-size:.8rem;font-weight:600;color:#fff}
.Excellent,.Good{background:#00B894}.Watch{background:#E0A800}.Critical{background:#D63031}
.w-critical{background:#FDECEA;border-left:5px solid #D63031;padding:8px 12px;border-radius:8px;margin:4px 0}
.w-warning{background:#FFF7E0;border-left:5px solid #E0A800;padding:8px 12px;border-radius:8px;margin:4px 0}
.w-info{background:#EEF2FF;border-left:5px solid #6C5CE7;padding:8px 12px;border-radius:8px;margin:4px 0}
</style>""", unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>🎓 Course Feedback Analyzer</h1>'
            '<p>Collect · Validate · Summarize student feedback</p></div>', unsafe_allow_html=True)


def card(label, value, color="#6C5CE7"):
    return f'<div class="card" style="border-left-color:{color}"><div class="l">{label}</div><div class="v">{value}</div></div>'


records = storage.load()

with st.sidebar:
    page = st.radio("Navigate", ["📊 Dashboard", "✍️ Submit Feedback", "🔎 Browse & Search",
                                 "📥 Bulk Import", "📤 Export"], label_visibility="collapsed")
    st.divider()
    st.caption(f"{len(records)} records stored")
    if st.button("Load sample data", help="Imports data/sample_feedback.csv (duplicates skipped)"):
        res = storage.import_csv(Path(__file__).parent / "data" / "sample_feedback.csv")
        st.success(f"Imported {res['imported']}"); st.rerun()

# ---------------------------------------------------------------- Dashboard
if page.endswith("Dashboard"):
    s = A.summary(records)
    if not s["total"]:
        st.info("No feedback yet. Submit an entry or click **Load sample data** in the sidebar.")
    else:
        stat_color = {"Excellent": "#00B894", "Good": "#00B894", "Watch": "#E0A800", "Critical": "#D63031"}[s["status"]]
        c = st.columns(5)
        c[0].markdown(card("Responses", s["total"]), unsafe_allow_html=True)
        c[1].markdown(card("Average rating", f"{s['avg']} ★", stat_color), unsafe_allow_html=True)
        c[2].markdown(card("Satisfied (4–5)", f"{s['pct_positive']}%"), unsafe_allow_html=True)
        c[3].markdown(card("Trend", s["trend_direction"]), unsafe_allow_html=True)
        c[4].markdown(card("Status", f'<span class="pill {s["status"]}">{s["status"]}</span>', stat_color), unsafe_allow_html=True)
        st.write("")
        a, b = st.columns(2)
        a.pyplot(charts.distribution_fig(records)); b.pyplot(charts.trend_fig(records))
        a, b = st.columns(2)
        a.pyplot(charts.course_fig(records))
        with b:
            st.subheader("Common themes")
            st.write(" ".join(f"`{w}` ×{n}" for w, n in s["keywords"]))
            if s["phrases"]:
                st.caption("Frequent phrases: " + ", ".join(f"{p} ({n})" for p, n in s["phrases"]))
            sent = s["sentiment"]
            st.subheader("Comment sentiment")
            st.bar_chart(pd.DataFrame({"count": sent}))
        st.subheader("Course & category breakdown")
        a, b = st.columns(2)
        a.dataframe(pd.DataFrame(s["courses"]), hide_index=True, use_container_width=True)
        b.dataframe(pd.DataFrame(s["categories"]), hide_index=True, use_container_width=True)
        w = A.warnings(records)
        st.subheader(f"⚠️ Alerts ({len(w)})")
        for x in w[:15]:
            st.markdown(f'<div class="w-{x["level"]}"><b>{x["level"].upper()}</b> — {x["msg"]}</div>', unsafe_allow_html=True)

# ---------------------------------------------------------------- Submit
elif page.endswith("Submit Feedback"):
    st.subheader("Submit course feedback")
    with st.form("fb", clear_on_submit=False):
        a, b = st.columns(2)
        course = a.text_input("Course code", placeholder="CS101")
        category = b.selectbox("Category", CATEGORIES)
        rating = st.slider("Rating", 1, 5, 4)
        comment = st.text_area("Comment", max_chars=600, placeholder="What worked? What could be better?")
        a, b = st.columns(2)
        d = a.date_input("Date", value=date.today())
        student = b.text_input("Name (optional)", placeholder="Anonymous")
        ok = st.form_submit_button("Submit feedback", type="primary")
    if ok:
        try:
            rec = storage.add({"course": course, "rating": rating, "category": category,
                               "comment": comment, "date": d, "student": student})
            st.success(f"Saved ✔ (id {rec.id})"); st.balloons()
        except V.ValidationError as e:
            for msg in str(e).split("; "):
                st.error(msg)

# ---------------------------------------------------------------- Browse
elif page.endswith("Browse & Search"):
    st.subheader("Browse & search")
    a, b, c_, d = st.columns([2, 1, 1, 1])
    kw = a.text_input("Keyword", placeholder="search comments, course, student")
    cat = b.selectbox("Category", ["All"] + CATEGORIES)
    course = c_.selectbox("Course", ["All"] + sorted({r.course for r in records}))
    lo, hi = d.slider("Rating", 1, 5, (1, 5))
    res = A.search(records, kw, "" if cat == "All" else cat, "" if course == "All" else course, lo, hi)
    st.caption(f"{len(res)} of {len(records)} records")
    df = pd.DataFrame([r.to_dict() for r in res])
    if not df.empty:
        df["sentiment"] = [A.sentiment_label(A.sentiment(r.comment)) for r in res]
        st.dataframe(df[["id", "date", "course", "rating", "category", "sentiment", "student", "comment"]],
                     hide_index=True, use_container_width=True)
        with st.expander("Delete a record"):
            rid = st.selectbox("Record id", df["id"])
            if st.button("Delete", type="secondary"):
                storage.delete(rid); st.rerun()

# ---------------------------------------------------------------- Import
elif page.endswith("Bulk Import"):
    st.subheader("Bulk CSV import")
    st.caption("Required columns: course, rating, category, comment, date (optional: student)")
    up = st.file_uploader("Choose a CSV", type="csv")
    if up and st.button("Import", type="primary"):
        res = storage.import_csv_text(up.getvalue().decode("utf-8-sig"))
        st.success(f"Imported {res['imported']} · skipped {res['skipped']}")
        if res["errors"]:
            st.dataframe(pd.DataFrame(res["errors"], columns=["row", "problem"]), hide_index=True, use_container_width=True)

# ---------------------------------------------------------------- Export
else:
    st.subheader("Export reports")
    if not records:
        st.info("Nothing to export yet.")
    else:
        a, b, c = st.columns(3)
        a.download_button("⬇ Markdown report", export.to_markdown(records), "report.md", "text/markdown")
        b.download_button("⬇ Audit log (.txt)", export.to_audit_log(records), "audit_log.txt")
        c.download_button("⬇ CSV", export.to_csv(records), "report.csv", "text/csv")
        if st.button("Save all reports + charts to ./exports"):
            paths = export.export_all(records, Path(__file__).parent / "exports")
            st.success("Saved: " + ", ".join(p.name for p in paths))
        st.markdown(export.to_markdown(records))
